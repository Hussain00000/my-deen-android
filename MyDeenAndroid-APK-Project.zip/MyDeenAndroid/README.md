# My Deen — Android Studio project

This is a native Kotlin + Jetpack Compose Android project for the personal Deen checklist.

## Build an APK
1. Install Android Studio (current stable) on a computer.
2. Open this `MyDeenAndroid` folder in Android Studio.
3. Let Gradle sync and install Android SDK Platform 35 if prompted.
4. Connect an Android phone or use an emulator.
5. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio creates the debug APK under `app/build/outputs/apk/debug/app-debug.apk`.

## Reminder behavior
- Morning and nightly alarms use Android `AlarmManager`.
- Exact alarms are requested where Android allows them; if exact-alarm access is unavailable, the app falls back to an inexact idle-friendly alarm.
- Notifications require the Android 13+ notification permission.
- Alarms are rescheduled after device restart, time change, and timezone change.
- For best punctuality, allow notifications and exact alarms, and exempt the app from aggressive battery restrictions if your phone delays alarms.

## Notes
- Checklist data and review notes are stored locally using SharedPreferences.
- Daily checklist keys are date-scoped; the cumulative Umari Qaza count persists across days.
- The two Tasbeeh rows are provisional labels because the diary handwriting was not fully legible. Confirm their exact names before treating them as final.
- This is a personal organizer, not a religious ruling or prayer-time calculator.


## Build an APK online with GitHub Actions
This project includes `.github/workflows/build-apk.yml`. To build without installing Android Studio:
1. Create a GitHub account and a new repository.
2. Extract this ZIP, open the `MyDeenAndroid` folder, and upload everything inside it to the repository root, including the hidden `.github` folder.
3. Open the repository's **Actions** tab and select **Build My Deen APK**.
4. Choose **Run workflow** if it has not started automatically, then wait for the run to finish.
5. Open the completed run and download the **My-Deen-debug-APK** artifact.
6. Extract the downloaded artifact and install `app-debug.apk` on your Android phone. If Android asks, allow installation from that browser or file manager.

This creates a debug APK for personal installation, not a Play Store release. The APK has not been compiled or device-tested in this workspace.
